// DSH 适配总验证（0.2.2 版）。
//
// 沿革：0.1.5 建立（verify-dsh-015-adaptation.mjs）→ 0.2.0 改名
// （verify-dsh-020-adaptation.mjs）→ 0.2.1 改名（verify-dsh-021-adaptation.mjs）
// → 0.2.2 改名到本文件名。文件名里的版本号是**它验的 DSH 版本**，不是仓库版本；
// 一个自称 015 却在验 0.2.0 的脚本只会误导人。
// `npm run verify:adaptation` 的入口名保持不变，所以既有调用不受影响。
//
// 0.2.1 实测结论（2026-10-22）：§5 的活 DSH 契约**逐项未漂移**——铸造 Cookie 鉴权、
// settings/describe + settings/update、agentPresets/list、session/create+selectModel、
// session/projections、control baseline 的 projections 形状、stopSessionWork、
// $events ready 帧、session/modelCatalog、斜杠式 endpoint 全部照旧。
// 唯一漂移在**工具面**：0.2.1 新增 `working_directory`（dsh-base 默认挂载，全局层继承）
// 以及 terminal / session-query / plugin_market 一族，守卫名单已同轮补齐。
//
// 0.2.2 实测结论（2026-11-05，DSH 0.2.2-rc.1）：§5 契约**同样逐项未漂移**；
// 补齐版本对账后 **77 通过 / 0 失败**（含 8 项语法检查；workspace-write 沙箱下
// 按既有约定跳过语法检查，计 69 通过）。工具面**定义/默认配置**漂移两处
// （默认不在 QQ preset 暴露，守卫补作回归网）：
//   · dsh-tool-fs 提供 `apply_patch`（默认 `applyPatch: false`；QQ preset 不挂 tool-fs）；
//   · 调度面 `schedule_update` / `schedule_delete` 改名 `schedule_view` / `schedule_edit`
//     （QQ preset 不挂 dsh-tool-schedule）。
// 0.2.2 及相邻版本声明的破坏性变更（tools.mode 移除、sessionProjections 注册改异步、
// agent/request 路由限制、实时 projection 帧改 changes[]、session/list summary
// 去掉 contextPressure 等）本仓库一处都没用到；`session/follow` 默认不再激活
// 冷会话（0.2.1-rc.3），桥接已显式传 `activate: true`（见 src/dsh-client.js）。
//
// 覆盖：
//   §1 仓库侧 preset persona schema
//   §2 部署侧 bundle patch / 守卫实现（preset 与 provider 行）
//   §3 版本身份一致性
//   §4 语法检查
//   §5 **运行中的 DSH 0.2.2 实测**（本文件的核心）：
//        · 鉴权：本机签名密钥离线铸造 Cookie
//        · settings/describe 可用，`qq-mode` 命名空间在列且可写
//          （0.2.0 删除了 ctx.settings.register()，命名空间改由 entry id + Config 推导）
//        · agentPresets/list 含 qq-chat / qq-chat-v2
//        · session/create 挂 preset + selectModel(deepseek-flash)
//        · session/projections 一元 RPC 可用（读队列的主路径）
//        · session/control 开场 baseline 是 value.projections[<id>].values.inbox
//          （**不再是** 0.1.7 的 value.queues[<id>] —— 认错形状会让每次退役会话都抛错）
//        · stopSessionWork 在真实会话上成功返回（这条是本次适配的核心回归）
//        · $events ready 帧
//        · session/modelCatalog 形状
//        · 点号 endpoint 仍不可用（协议确为斜杠式）
//
// 不依赖 SnowLuma。会创建探测会话、写回 qq-mode，并用 selectModel 选择
// deepseek-official/deepseek-flash/max；DSH 会把这个选择持久化为全局默认模型。
// 清理时停止并归档探测会话、删除独占的临时目录；不自动恢复全局默认模型，
// 以免覆盖运行期间用户或其他客户端的并发更改。
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { dshHome, dshModulesDir } from './dsh-modules.mjs';
import { discoverDshSessionCookie, NodeApiClient, unwrap } from '../src/dsh-client.js';
import { cleanupProbeSession, createProbeDirectory, probeMux, probeTurn } from './adaptation-probe-helpers.mjs';

const ROOT = process.cwd();
const DSH_MODULES = dshModulesDir();
const DSH_HOME = dshHome();
const BASE = process.env.DSH_BASE_URL || 'http://127.0.0.1:3080';

let pass = 0, fail = 0;
const results = [];
function check(label, cond, extra = '') {
  if (cond) { pass += 1; results.push(`✅ ${label}${extra ? ' — ' + extra : ''}`); }
  else { fail += 1; results.push(`❌ ${label}${extra ? ' — ' + extra : ''}`); }
  return cond;
}
/** 环境不允许断言时显式记为跳过，而不是假装通过。 */
function skip(label, why) {
  results.push(`⏭ ${label} — ${why}`);
  return false;
}

// ── 1. 仓库侧：preset persona schema ────────────────────────────────────────
const persona = await import(pathToFileURL(path.join(DSH_MODULES, '@deepseek-ai/dsh-persona/lib/index.js')).href);
const YAML = await import(pathToFileURL(path.join(DSH_MODULES, 'js-yaml/index.js')).href);
const yaml = YAML.default ?? YAML;

let oldRejected = false;
try { persona.Config({ text: 'x' }); } catch { oldRejected = true; }
check('dsh-persona 仍拒绝旧字段 text（故障前提成立）', oldRejected);

/** DSH 0.2.1 的 agent loop 只注册这两个提示词变量（0.2.0 还有 `cwd`）。 */
const DSH_PROMPT_VARIABLES = new Set(['provider', 'model']);

for (const p of ['qq-chat', 'qq-chat-v2']) {
  const f = path.join(ROOT, 'dsh/agent-presets', p, 'agent.cordis.yml');
  const row = yaml.load(fs.readFileSync(f, 'utf8')).find((r) => r.id === 'persona');
  let schemaOk = false;
  try { persona.Config(row.config); schemaOk = true; } catch {}
  check(`preset ${p}: persona.config 通过 DSH schema`, schemaOk);
  // 未知变量不是"渲染成空"而是 fail loud：回合直接 error、模型一次都不跑。
  // 所以这里必须钉住「只用 DSH 真注册过的变量」，而不只是「有 {{model}}」。
  const usedVars = [...new Set([...JSON.stringify(row.config).matchAll(/\{\{([a-z][a-z0-9_]*)\}\}/g)].map((m) => m[1]))];
  const unknownVars = usedVars.filter((v) => !DSH_PROMPT_VARIABLES.has(v));
  check(`preset ${p}: 只引用 DSH 已注册的提示词变量`,
    unknownVars.length === 0 && /\{\{model\}\}/.test(row.config.prefix),
    unknownVars.length ? `未知变量: ${unknownVars.join(', ')}` : usedVars.join(', '));
}

// ── 2. 部署侧：DSH 0.1.7 的 preset 机制 ──────────────────────────────────────
// 0.1.5 时这一节比的是 ~/.dsh/.agent-presets/<p>/ 下的安装副本；0.1.7 起该目录
// **完全不再被读取**（注册表既不扫目录也不接受 preset 路径），preset 变成 bundle
// patch 插入的一条 @deepseek-ai/dsh-agent-preset 行。因此这里改成核对：
//   ① bundle patch 与仓库权威源一致（生成器 --check，防手改/忘重新生成）；
//   ② bundle 已注册进 profile（link: 依赖 + bundles + node_modules junction，
//      守卫行的裸说明符就靠这个 junction 解析）；
//   ③ 守卫实现只有一份且 fail-closed。
const norm = (s) => s.replace(/\r\n/g, '\n');
const presetPatches = await import(pathToFileURL(path.join(ROOT, 'scripts/build-agent-preset-patches.mjs')).href);
for (const { file, changed } of presetPatches.buildPatches({ check: true, log: () => {} })) {
  check(`${path.relative(ROOT, file)} 与仓库源一致（未漂移）`, !changed);
}
for (const p of ['qq-chat', 'qq-chat-v2']) {
  const doc = yaml.load(fs.readFileSync(presetPatches.patchFileFor(p), 'utf8'));
  const row = doc?.[0]?.insert?.[0];
  check(`patch ${p}: 是 @deepseek-ai/dsh-agent-preset 行`, row?.name === '@deepseek-ai/dsh-agent-preset');
  check(`patch ${p}: config.id = ${p}`, row?.config?.id === p);
  const source = yaml.load(fs.readFileSync(path.join(ROOT, 'dsh/agent-presets', p, 'agent.cordis.yml'), 'utf8'));
  const srcPersona = source.find((r) => r.id === 'persona');
  const patchPersona = (row?.config?.plugins ?? []).find((r) => r.id === 'persona');
  check(`patch ${p}: persona.prefix 与源逐字一致`, norm(srcPersona?.config?.prefix ?? '') === norm(patchPersona?.config?.prefix ?? ''));
  const guardRow = (row?.config?.plugins ?? []).find((r) => r.id === 'qq-tool-restrict');
  check(`patch ${p}: 守卫行用 Profile 目录可解析的裸说明符`, guardRow?.name === presetPatches.GUARD_SPECIFIER);
}

// 守卫脚本必须是 fail-closed 的：非法工具名要被拒绝，而不是放行（权威实现只有一份）。
const canonicalGuardPath = path.join(ROOT, 'plugins', 'qq-agent-presets', 'qq-tool-restrict.mjs');
const guard = fs.readFileSync(canonicalGuardPath, 'utf8');
// 断言只看**可执行代码**：守卫的注释里会写「cordis_define/… 在 0.1.7 已被删除」做历史说明，
// 直接扫原文会把这段说明误判成「还在使用旧工具名」（实测误报）。必须**先剥块注释**
// （/∗ … ∗/ 与 JSDoc 的 ` * ` 行）**再剥行注释**，否则块注释里的旧名仍会被扫到。
// 剥行注释必须按 /\r?\n/ 切行：JS 的 `.` 不匹配 \r，CRLF 下 split('\n') 会让行尾留 \r，
// /\/\/.*$/ 的 `$` 够不到行尾。
const guardCode = guard
  .replace(/\/\*[\s\S]*?\*\//g, '')
  .split(/\r?\n/).map((l) => l.replace(/\/\/.*$/, '')).join('\n');
check('守卫：非法工具名 fail-closed（不接受裸 return 放行）', !/typeof name !== 'string'[^\n]*\)\s*return\s*$/m.test(guardCode));
check('守卫：不额外放行 web_search/web_fetch', !/'(?:web_search|web_fetch)'/.test(guardCode));
check('守卫：拒绝 0.1.7 已删除的 cordis 旧工具名（避免静默失效）', !/cordis_(?:define|undefine|run|stop)/.test(guardCode));

// 0.2.0 工具面重新对账的结果（扫描器与守卫必须一致）。
// 三类必须覆盖，来源见 plugins/qq-agent-presets/qq-tool-restrict.mjs 的长注释：
//   ① 全局层默认启用、仿真会话真的会继承的 MCP 资源工具
//   ② 派生 agent / 执行外部代码
//   ③ 插件装载权（= 任意代码执行）与无人值守的自我调度
const GUARD_020_NAMES = [
  'list_mcp_resources', 'list_mcp_resource_templates', 'read_mcp_resource',
  'subagent_codex', 'subagent_claude_code',
  'spawn_teammate', 'team_task_create', 'team_task_get', 'team_task_list', 'team_task_update',
  'plugin_manager',
  // 0.2.2 起 schedule_update / schedule_delete 改名（见 GUARD_022_NAMES），旧名已不注册。
  'schedule_create', 'schedule_list',
];
/** 0.2.1 对账新增的名字（见守卫长注释里 2026-10-22 那段）。 */
const GUARD_021_NAMES = [
  // dsh-base 0.2.1 默认挂载 ⇒ 全局层继承
  'working_directory',
  // dsh-tool-terminal：终端 = shell
  'terminal_open', 'terminal_send', 'terminal_read', 'terminal_signal', 'terminal_close', 'terminal_list',
  // dsh-tool-session-query：跨会话读事件正文
  'session_search', 'session_trace', 'session_event_read', 'session_event_search', 'session_event_trace',
  // 装载权 / 写盘起进程 / team 家族
  'plugin_market', 'create_worktree', 'wait_agent',
];
/**
 * 0.2.2 对账新增的名字（见守卫长注释里 2026-11-05 那段）。
 * 同一轮删掉了 `schedule_update` / `schedule_delete`：0.2.2 把它们改名为
 * `schedule_view` / `schedule_edit`，旧名不再注册，留着只会被 restrict 抛错吞掉。
 */
const GUARD_022_NAMES = [
  // dsh-tool-fs 新增：一次多文件新增/编辑/删除/移动
  'apply_patch',
  // 调度面改名后的新名字
  'schedule_view', 'schedule_edit',
];
const guardMod = await import(pathToFileURL(canonicalGuardPath).href);
const guardNames = new Set(guardMod.RESTRICTED_TOOL_NAMES ?? []);
const optionalNames = new Set(guardMod.OPTIONAL_BUNDLE_TOOL_NAMES ?? []);
const missingFromGuard = GUARD_020_NAMES.filter((n) => !guardNames.has(n));
check('守卫已覆盖 0.2.0 新增的危险工具名', missingFromGuard.length === 0, missingFromGuard.join(', ') || `${guardNames.size} 个名字`);
const missingFromGuard021 = GUARD_021_NAMES.filter((n) => !guardNames.has(n));
check('守卫已覆盖 0.2.1 新增的危险工具名', missingFromGuard021.length === 0, missingFromGuard021.join(', ') || `${GUARD_021_NAMES.length} 个名字`);
const missingFromGuard022 = GUARD_022_NAMES.filter((n) => !guardNames.has(n));
check('守卫已覆盖 0.2.2 新增的危险工具名', missingFromGuard022.length === 0, missingFromGuard022.join(', ') || `${GUARD_022_NAMES.length} 个名字`);

// 守卫名单里的每个名字都必须是 DSH 真实注册的工具：`tools.restrict()` 对未知名字会抛错，
// 而守卫逐个 try/catch 只打日志 ⇒ 拼错的名字 = 静默 no-op。
// 扫描器（scripts/scan-dsh-tool-names.mjs）与 test-preset-local-tools.mjs 共用
// scripts/dsh-tool-names.mjs 这一份抽取实现，所以这里直接复用，不会出现两套口径。
const { collectDshToolNames } = await import(pathToFileURL(path.join(ROOT, 'scripts/dsh-tool-names.mjs')).href);
const scanned = collectDshToolNames();
if (scanned.names.size === 0) {
  skip('守卫名单与 DSH 真实工具名对账', '未扫到任何 DSH 包（DSH 未安装？）');
} else {
  const fabricated = [...guardNames]
    .filter((n) => !n.startsWith('dev_') && !optionalNames.has(n) && !scanned.names.has(n));
  check('守卫名单无拼错的假名（restrict 不会静默失效）', fabricated.length === 0, fabricated.join(', ') || `扫过 ${scanned.packages.length} 个包`);
}

const patch = fs.readFileSync(path.join(DSH_HOME, 'profiles/web/cordis.patch.yml'), 'utf8');
const patchDoc = yaml.load(patch);
const mcpIds = patchDoc.filter((e) => e?.insert).flatMap((e) => e.insert.map((x) => x.id));
check('profile patch 含 3 个 MCP 且无重复', mcpIds.length === 3 && new Set(mcpIds).size === 3, mcpIds.join(', '));
const snowlumaEntry = patchDoc.filter((e) => e?.insert).flatMap((e) => e.insert).find((x) => x.id === 'mcp-snowluma');
check('mcp-snowluma 带 toolCallTimeoutMs=725000', snowlumaEntry?.config?.toolCallTimeoutMs === 725000);
check('mcp 路径指向本仓库', mcpIds.every((id) => {
  const e = patchDoc.filter((x) => x?.insert).flatMap((x) => x.insert).find((y) => y.id === id);
  return String(e.config.args[0]).includes('qq-bridge');
}));

const pkg = JSON.parse(fs.readFileSync(path.join(DSH_HOME, 'profiles/web/package.json'), 'utf8'));
check('profile bundles 含 qq-mode-console', pkg.dsh.profile.bundles.includes('qq-mode-console'));
check('qq-mode-console link 依赖已注册', String(pkg.dependencies['qq-mode-console'] ?? '').startsWith('link:'));
check('qq-mode-console 已 link 进 node_modules', fs.existsSync(path.join(DSH_HOME, 'profiles/web/node_modules/qq-mode-console')));

// ── 3. 仓库配置：模型 ───────────────────────────────────────────────────────
const cfg = JSON.parse(fs.readFileSync(path.join(ROOT, 'config.json'), 'utf8'));
check('config.json dsh.model = deepseek-flash', cfg.dsh?.model === 'deepseek-flash', `当前 ${cfg.dsh?.model}`);
const bridgeSrc = fs.readFileSync(path.join(ROOT, 'src/bridge.js'), 'utf8');
// 只看可执行代码，忽略注释（注释里会提到旧名做历史说明）。
// 注意必须按 /\r?\n/ 切行：JS 的 `.` 不匹配 \r，CRLF 文件直接 split('\n') 会让行尾留 \r，
// 导致 /\/\/.*$/ 的 `$` 够不到行尾、注释根本剥不掉（曾因此误报）。
const stripComments = (src) => src.split(/\r?\n/).map((l) => l.replace(/\/\/.*$/, '')).join('\n');
const bridgeCode = stripComments(bridgeSrc);
check('bridge.js 可执行代码无 deepseek-v4-flash-vision-exp 残留', !bridgeCode.includes('deepseek-v4-flash-vision-exp'));
check('bridge.js 可执行代码无 router-standard 残留', !bridgeCode.includes('router-standard'));
// setup-dsh.mjs 曾被漏改：0.1.5 适配只清了 bridge.js，脚本里仍在写死已下线的 preset 名。
const setupCode = stripComments(fs.readFileSync(path.join(ROOT, 'scripts/setup-dsh.mjs'), 'utf8'));
check('setup-dsh.mjs 可执行代码无 router-standard 残留', !setupCode.includes('router-standard'));
check('setup-dsh.mjs 新装默认 closedAgentPreset 留空（交给 DSH 默认 preset）', /closedAgentPreset:\s*''/.test(setupCode));
check('bridge.js 默认模型为 deepseek-flash', /model:\s*'deepseek-flash'/.test(bridgeCode));
check('bridge.js 不再有「无参创建会话」兜底', !/sessions\.create\(\{\}\)/.test(bridgeCode));
check('bridge.js 含 preset 清单/默认 preset 解析', bridgeSrc.includes('resolvePresetName') && bridgeSrc.includes('refreshPresetList'));

// 安全不变量回归防线：群聊/仿真会话在 preset 缺失时必须 fail-closed。
// 旧实现会在 preset 不在 DSH 清单里时静默回退到 DSH 默认 preset（standard，含 bash/
// 文件读写），把本地工具暴露给 QQ 群 —— 与 RULES.md「无本地工具」的承诺直接矛盾。
check('preset 解析带 strict 开关', /resolvePresetName\(name, \{ strict = false \} = \{\}\)/.test(bridgeCode));
check('非 closed-agent 模式以 strict 解析 preset', /resolvePresetName\(wanted, \{ strict: true \}\)/.test(bridgeCode));
check('群聊模式缺少 preset 时拒绝建会话（fail-closed）', /strictPreset && !preset/.test(bridgeCode));
check('群聊模式不再重试「无 preset」建会话', /strictPreset \? \[true\] : \[true, false\]/.test(bridgeCode));

// ── 3b. 版本身份一致性 ──────────────────────────────────────────────────────
// v0.1.5 曾带着自称 0.1.2-alpha.1 的 package-lock.json 发布出去（package.json 却是
// 0.1.5），三个 MCP server 的 serverInfo.version 也停在 0.1.0。版本漂移没有防线就会
// 复发，这里把「所有对外自称的版本号必须等于 package.json」固定下来。
const pkgJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'package.json'), 'utf8'));
const lockJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'package-lock.json'), 'utf8'));
const pluginPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugins/qq-mode-console/package.json'), 'utf8'));
const presetsPkg = JSON.parse(fs.readFileSync(path.join(ROOT, 'plugins/qq-agent-presets/package.json'), 'utf8'));
check('package-lock.json 顶层 version 与 package.json 一致', lockJson.version === pkgJson.version, `lock=${lockJson.version} pkg=${pkgJson.version}`);
check('package-lock.json packages[""] version 与 package.json 一致', lockJson.packages?.['']?.version === pkgJson.version, `lock=${lockJson.packages?.['']?.version}`);
check('qq-mode-console 插件版本与主包一致', pluginPkg.version === pkgJson.version, `plugin=${pluginPkg.version}`);
check('qq-agent-presets 插件版本与主包一致', presetsPkg.version === pkgJson.version, `plugin=${presetsPkg.version}`);
for (const f of ['src/mcp-snowluma-safe.js', 'src/mcp-host-server.js', 'src/mcp-web-search-safe.js']) {
  const m = /new McpServer\(\{[^}]*version:\s*'([^']+)'/.exec(fs.readFileSync(path.join(ROOT, f), 'utf8'));
  check(`${f} 的 MCP serverInfo.version 与主包一致`, m?.[1] === pkgJson.version, `声明=${m?.[1]} 主包=${pkgJson.version}`);
}

// ── 4. 语法检查 ─────────────────────────────────────────────────────────────
// 注意 spawnSync 在受限环境（DSH 沙箱的 workspace-write）会以 EPERM 失败——
// 那是**环境**不允许起子进程，不是文件有语法错。这种情况显式记为跳过，
// 否则会输出一串假失败，把真正的失败淹掉（实测踩过）。
const SYNTAX_FILES = ['src/bridge.js', 'src/dsh-client.js', 'src/mcp-snowluma-safe.js', 'src/mcp-host-server.js', 'src/mcp-web-search-safe.js', 'src/slang-learner.js', 'src/self-test.js', 'scripts/setup-dsh.mjs'];
{
  const probe = spawnSync(process.execPath, ['--check', path.join(ROOT, 'src/dsh-client.js')], { encoding: 'utf8' });
  if (probe.error?.code === 'EPERM') {
    skip(`${SYNTAX_FILES.length} 个文件的语法检查`, '本环境不允许 spawn 子进程（EPERM）；请在普通终端重跑');
  } else {
    for (const f of SYNTAX_FILES) {
      const r = spawnSync(process.execPath, ['--check', path.join(ROOT, f)], { encoding: 'utf8' });
      check(`${f} 语法正确`, r.status === 0, (r.stderr || '').split('\n')[0]);
    }
  }
}

// ── 5. 运行中的 DSH 0.2.2 ───────────────────────────────────────────────────
console.warn('活体验证会创建并归档探测会话、写回 qq-mode，消耗一次模型回合，'
  + '并将 DSH 全局默认模型改为 deepseek-official/deepseek-flash/max；不会自动恢复默认模型。');
// 鉴权走与桥接生产代码同一条路：用 ~/.dsh 里持久化的签名密钥离线铸造会话 Cookie。
// 旧写法（从 ~/.dsh/guard/logs/server-*.out.log 里抓 `?token=`）在 0.1.7 已经死了：
//   · 进程启动 token 是现生成的 32 字节随机数，只存在内存 WeakMap 里，不落盘；
//   · guard 插件退役后也没有启动器再把 `dsh web` 的 stdout 重定向到那个目录，
//     日志里剩下的是**上一个进程**的陈旧 token，换 Cookie 只会得到 401。
const cookie = discoverDshSessionCookie(BASE);
check('本机签名密钥 → 铸造会话 Cookie 成功', Boolean(cookie), cookie ? `${cookie.length} 字节` : '读不到 browser-session 密钥');
async function rpc(e, a) {
  const r = await fetch(`${BASE}/api/${e}`, { method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: JSON.stringify({ type: 'client-request', rpcId: 'v' + Math.random().toString(36).slice(2, 8), method: e, payload: { args: a } }) });
  return (await r.json()).result;
}
const st = await rpc('settings/describe', {});
check('settings/describe 可用', st.ok === true);
const dm = st.value?.namespaces?.find((n) => n.ns === 'agent-default-model');
check('DSH 全局默认模型 = deepseek-flash', dm?.value?.model === 'deepseek-flash', `当前 ${dm?.value?.model}`);
const ap = await rpc('agentPresets/list', {});
const presetIds = ap.value?.presets?.map((p) => p.id) ?? [];
check('agentPresets/list 含 qq-chat 与 qq-chat-v2', presetIds.includes('qq-chat') && presetIds.includes('qq-chat-v2'), presetIds.join(', '));
// 0.1.7 把设置命名空间从 `agent-presets` 改名为 `agent-preset-registry`，而且「用户默认」
// 是易失字段 selectedDefault，不会出现在 describe 的 value 里。部署默认由 registry 行的
// config.default 决定（dsh-web-app 的 patch 写的是 standard）。桥接在 closedAgentPreset
// 留空时依赖的正是它，所以这里断言「注册表已装载」+「standard 预设存在」这两件可观测的事。
const registryNs = st.value?.namespaces?.find((n) => n.ns === 'agent-preset-registry');
check('preset 注册表命名空间已装载', registryNs !== undefined, st.value?.namespaces?.map((n) => n.ns).filter((n) => n.includes('preset')).join(', '));
check('closed-agent 兜底所需的 standard 预设可用', presetIds.includes('standard'), presetIds.join(', '));

// ── 5a. qq-mode 命名空间（0.2.0 删除了 ctx.settings.register()）──────────────
// 0.2.0 里命名空间**不再需要注册**：它由 profile 里 id 恰好等于命名空间名的 loader
// entry + 该插件导出的 Config（含 volatile 字段）推导出来。这条断言把「模式能写穿
// DSH 设置」的可观测结果钉住 —— 它一旦坏掉，控制台改模式只在本地生效，下一次
// DSH 轮询就回滚，而且不会有任何提示。
const qqMode = st.value?.namespaces?.find((n) => n.ns === 'qq-mode');
check('settings/describe 列出 qq-mode 命名空间', qqMode !== undefined, st.value?.namespaces?.map((n) => n.ns).length + ' 个命名空间');
if (qqMode) {
  // settings 的 user 层可能已更新而运行时 value 尚未热更新，不能把旧模式写回。
  const currentMode = Object.hasOwn(qqMode.user ?? {}, 'mode') ? qqMode.user.mode : qqMode.value?.mode;
  check('qq-mode 带 mode 字段', typeof currentMode === 'string', JSON.stringify({ mode: currentMode }));
  check('qq-mode 带 revision（写入所需）', Number.isInteger(qqMode.revision), String(qqMode.revision));
  // settings/update 是**多参数** RPC：args 是 { ns, patch, expectedRevision } 平铺，
  // 不是 { request: {...} }（传 request 会被网关拒为
  // `gateway/arguments-invalid: missing "ns", "patch"; unexpected "request"`）。
  const writeBack = await rpc('settings/update', {
    ns: 'qq-mode', patch: { mode: currentMode }, expectedRevision: qqMode.revision,
  });
  check(
    'settings/update 可写 qq-mode（参数为平铺多参数，非 request 包装）',
    writeBack.ok === true,
    writeBack.ok ? `mode=${writeBack.value?.value?.mode}` : `${writeBack.error?.code}: ${writeBack.error?.message}`,
  );
}

// ── 5b. session/projections：读会话队列的主路径 ──────────────────────────────
const probeDir = createProbeDirectory();
const api = new NodeApiClient(BASE, undefined, {});

let probeSessionId = null;
try {
  await api.ensureAuth();
  const created = unwrap(await api.sessions.create({ cwd: probeDir, agentPreset: 'qq-chat-v2' }), 'session.create');
  probeSessionId = created.sessionId;
  check('session/create 挂 qq-chat-v2 preset 成功', typeof probeSessionId === 'string' && probeSessionId.length > 0, probeSessionId);
  unwrap(await api.sessions.selectModel({
    sessionId: probeSessionId, provider: 'deepseek-official', model: 'deepseek-flash', reasoningEffort: 'max'
  }), 'session.selectModel');
  check('session/selectModel(deepseek-flash) 被接受', true);

  const projections = await api.callUnary('session/projections', { sessionId: probeSessionId });
  check('session/projections 一元 RPC 可用', projections.result?.ok === true,
    projections.result?.ok ? '' : `${projections.result?.error?.code}: ${projections.result?.error?.message}`);
  const values = projections.result?.value?.values;
  check('session/projections 返回 values.inbox（next-turn / next-step）',
    values?.inbox !== undefined && Array.isArray(values.inbox['next-turn']) && Array.isArray(values.inbox['next-step']),
    Object.keys(values ?? {}).slice(0, 6).join(','));

  // ── 5c. control baseline 形状（0.2.0 的核心断裂点）────────────────────────
  const url = new URL('/api/remote.mux', BASE);
  url.protocol = url.protocol === 'https:' ? 'wss:' : 'ws:';
  const baseline = await probeMux({
    url, cookie: api.cookie, endpoint: 'session/control', args: {}, timeoutMs: 15_000,
    onItem: (value) => value?.type === 'baseline' ? value : undefined,
  }).catch((error) => { check('session/control 开场 baseline 形状', false, error.message); return null; });
  if (baseline) {
    const bv = baseline.value;
    check('control baseline 是 value.projections（0.2.0 形状）',
      bv !== null && typeof bv?.projections === 'object' && bv.projections !== null);
    check('control baseline 不再有 value.queues（0.1.7 形状已废弃）',
      bv !== null && !Object.hasOwn(bv ?? {}, 'queues'));
    const sample = bv?.projections?.[probeSessionId]?.values;
    check('baseline 里探测会话的投影带 inbox', sample?.inbox !== undefined,
      Object.keys(sample ?? {}).slice(0, 6).join(','));
  }

  // ── 5d. 核心回归：退役会话不再抛 baseline 结构错 ─────────────────────────
  // 0.2.0 之前这段代码读 `value.queues[<id>]`，形状一变就**每次**退役都抛
  // "invalid session/control baseline"，队列清不掉、旧任务继续在 DSH 里跑，
  // 而桥接日志里只有一行警告。这条断言就是那次断裂的回归网。
  let retireError = null;
  let retired = null;
  try { retired = await api.stopSessionWork(probeSessionId); }
  catch (error) { retireError = error; }
  check('stopSessionWork 在真实会话上成功返回（不再抛 baseline 结构错）',
    retireError === null, retireError?.message ?? `removed=${retired?.removed}`);

  // ── 5e. $events ready 帧 ─────────────────────────────────────────────────
  const readyFrame = await probeMux({
    url, cookie: api.cookie, endpoint: '$events', args: {}, timeoutMs: 10_000,
    onItem: (value) => value?.type === 'ready' ? value : undefined,
  }).catch(() => null);
  check('$events 下发 ready 帧并带 clientId',
    typeof readyFrame?.clientId === 'string' && readyFrame.clientId.length > 0,
    readyFrame ? `${String(readyFrame.clientId).slice(0, 8)}…` : '未收到 ready 帧');

  // ── 5f. session/modelCatalog 形状 ────────────────────────────────────────
  const catalog = await api.callUnary('session/modelCatalog', {});
  check('session/modelCatalog 可用且给出模型分组', catalog.result?.ok === true && Array.isArray(catalog.result?.value?.groups),
    catalog.result?.ok ? `${catalog.result.value.groups.length} 组` : `${catalog.result?.error?.code}`);

  // ── 5g. preset 真跑一个回合：提示词变量可解析（0.2.1 断裂点回归网）──────────
  // 0.2.1 把 `cwd` 从 agent loop 的提示词变量表里删掉了（只剩 provider / model）。
  // system prompt 对未知变量是 fail loud ⇒ 回合在 turn/start 后立刻 error，
  // 模型一次都不跑，QQ 上表现为「完全不回」。静态断言只能看出"写了什么变量"，
  // 只有真跑一回合才能证明它**可解析**。
  let turnSessionId = null;
  try {
    const turnSession = unwrap(await api.sessions.create({ cwd: probeDir, agentPreset: 'qq-chat-v2' }), 'session.create(turn)');
    turnSessionId = turnSession.sessionId;
    unwrap(await api.sessions.selectModel({ sessionId: turnSessionId, provider: 'deepseek-official', model: 'deepseek-flash', reasoningEffort: 'max' }), 'session.selectModel(turn)');
    const turn = await probeTurn(api, turnSessionId, { url, cookie: api.cookie, timeoutMs: 90_000 });
    const kind = typeof turn.reason === 'string' ? turn.reason : turn.reason?.kind;
    const why = turn.reason?.error?.message;
    check('preset 真跑一回合：提示词变量可解析且正常结束',
      kind === 'completed' && turn.text.length > 0,
      kind === 'completed' ? `text=${JSON.stringify(turn.text.slice(0, 24))}` : `${kind ?? 'no turn/end'}${why ? `: ${why}` : ''}`);
  } catch (error) {
    check('preset 真跑一回合：提示词变量可解析且正常结束', false, error?.message ?? String(error));
  } finally {
    if (turnSessionId) {
      const errors = await cleanupProbeSession(api, turnSessionId);
      check('真实回合探测会话已停止并归档', errors.length === 0, errors.join('; '));
    }
  }
} catch (error) {
  check('DSH 实测段无未捕获异常', false, error?.message ?? String(error));
} finally {
  if (probeSessionId) {
    const errors = await cleanupProbeSession(api, probeSessionId);
    check('协议探测会话已停止并归档', errors.length === 0, errors.join('; '));
  }
  try { fs.rmSync(probeDir, { recursive: true, force: true }); }
  catch (error) { check('临时探测目录已删除', false, error?.message ?? String(error)); }
}

// 点号 endpoint（旧协议）应返回纯文本 404（不是 JSON 信封）——证明协议确为斜杠式
const dotRes = await fetch(`${BASE}/api/session.list`, {
  method: 'POST', headers: { cookie, 'content-type': 'application/json' },
  body: JSON.stringify({ type: 'client-request', rpcId: 'v-dot', method: 'session.list', payload: { args: { _request: {} } } }),
});
const dotBody = await dotRes.text();
check('点号 endpoint /api/session.list 不可用（旧协议已废弃）', dotRes.status === 404 && /not found/i.test(dotBody), `HTTP ${dotRes.status}`);

// ── 汇总 ────────────────────────────────────────────────────────────────────
console.log(results.join('\n'));
console.log(`\n总计: ${pass} 通过, ${fail} 失败`);
// 用 process.exitCode 而不是 process.exit()：后者会在 undici 的 keep-alive socket
// 仍在关闭途中强行拆掉事件循环，在 Windows 上触发 libuv 断言
// （Assertion failed: !(handle->flags & UV_HANDLE_CLOSING), src\win\async.c）。
// 结果是「断言全过但退出码非 0」，CI 会误判失败。设 exitCode 让循环自然排空即可。
process.exitCode = fail === 0 ? 0 : 1;
